import { S3Client, PutObjectCommand } from "@aws-sdk/client-s3";
var s3 = new S3Client();

export const uploadJsonFileToS3 = async (data) => {

    let params = {
        Body: JSON.stringify(data), 
        Bucket: "sellout-management-data", 
        Key: "exampleobject.json",
        ContentType: "application/json; charset=utf-8",
    };

    let uploadResponse = await s3.send(new PutObjectCommand(params));
    console.log(uploadResponse);
};
