import axios from 'axios';

export const getAccessToken = async (grantType, accessTokenURL, method, clientId, clientSecret, scope) => {
    let options = {
      method: method,
      url: accessTokenURL,
      headers: {'content-type': 'application/x-www-form-urlencoded'},
      data: new URLSearchParams({
        grant_type: grantType,
        client_id: clientId,
        client_secret: clientSecret,
        scope: scope
      })
    };
    let response = await axios(options);
    console.log(response);
    if(response && response.data){
        return response.data.access_token;
    }
    throw new Error("Error getting AccessToken");
};


export const sendRequest = async (method, url, data, accessToken) => {
    console.log('sending payload', data);
  
      let options = {
          method: method,
          url: url,
          data: data,
          headers: {'content-type': 'application/json' , authorization: ('Bearer ' + accessToken)}
      };

      let response = await axios(options);
      return response;
  };