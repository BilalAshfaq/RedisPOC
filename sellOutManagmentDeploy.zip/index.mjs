import { getAccessToken, sendRequest } from './requestUtils.mjs';
import { uploadJsonFileToS3 } from './s3Helper.mjs'; 

export const handler = async (event) => {
  // TODO implement
  console.log(event);
  let token = await getAccessToken('client_credentials', 'https://login.microsoftonline.com/fcb2b37b-5da0-466b-9b83-0014b67a7c78/oauth2/v2.0/token', 'POST', 'b815645b-fb47-4d44-9786-f4f92c35d798', 'N778Q~Ll6gSkEjXswHRdYNEHzI6X~H67NvAVDam1', 'b815645b-fb47-4d44-9786-f4f92c35d798/.default');
  console.log('Token ', token);
  
  let apiResponse = await sendRequest('POST', 'https://api01.agro.services/selloutmngt-api/output', event, token);
  console.log(apiResponse);
  await uploadJsonFileToS3(apiResponse.data);
  return apiResponse.data;
  
};
